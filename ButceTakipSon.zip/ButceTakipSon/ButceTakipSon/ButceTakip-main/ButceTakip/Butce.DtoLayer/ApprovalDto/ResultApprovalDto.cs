﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.DtoLayer.ApprovalDto
{
    public class ResultApprovalDto
    {

        public string Companyname { get; set; }

        public string WorkName { get; set; }

        public string WorkType { get; set; }

        public int VAT { get; set; }

        public int ExcVAT { get; set; }

        public int InVAT { get; set; }
    }
}
