﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.DtoLayer.MainCodeDto
{
    public class UpdateMainCodeDto
    {

        public int MainCodeID { get; set; }

        public string MainCodes { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }
    }
}
