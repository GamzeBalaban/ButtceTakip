﻿using Butce.BusinessLayer.Abstract;
using Butce.DataAccessLayer.Abstract;
using Butce.EntityLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.BusinessLayer.Concrete
{
    public class PersonelManager : IPersonelService
    {
        private readonly IPersonalDal _personelDal;

        public PersonelManager(IPersonalDal personelDal)
        {
            _personelDal = personelDal;
        }

        public void TAdd(Personel entity)
        {
            _personelDal.Add(entity);
        }

        public void TDelete(Personel entity)
        {
            _personelDal.Delete(entity);
        }

        public List<Personel> TGetAll()
        {
            return _personelDal.GetAll();
        }

        public Personel TGetByID(int id)
        {
           return  _personelDal.GetByID(id);
        }

        public void TUpdate(Personel entity)
        {
            _personelDal.Update(entity);
        }
    }
}
