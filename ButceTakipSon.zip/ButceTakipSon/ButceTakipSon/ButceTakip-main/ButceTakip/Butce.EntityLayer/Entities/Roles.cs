﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.EntityLayer.Entities
{
    public class Roles
    {
        public int RoleID { get; set; }

        public string PersonelRoles { get; set; }

        public string PersonelState { get; set; }
    }
}
