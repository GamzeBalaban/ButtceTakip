﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.EntityLayer.Entities
{
    public class Proxy
    {

        public int ProxyID { get; set; }

        public string Name  { get; set; }

        public string PersonelTask { get; set; }
        public string PersonelState { get; set; }
    }
}
