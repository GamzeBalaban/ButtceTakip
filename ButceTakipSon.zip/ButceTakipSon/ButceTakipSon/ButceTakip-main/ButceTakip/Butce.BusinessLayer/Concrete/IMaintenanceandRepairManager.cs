﻿using Butce.BusinessLayer.Abstract;
using Butce.DataAccessLayer.Abstract;
using Butce.DataAccessLayer.EntityFramework;
using Butce.EntityLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.BusinessLayer.Concrete
{
    public class IMaintenanceandRepairManager : IMaintenanceandRepairService
    {
        private readonly IMaintenanceandRepairDal _maintenanceandRepairDal;

        public IMaintenanceandRepairManager(IMaintenanceandRepairDal maintenanceandRepairDal)
        {
            _maintenanceandRepairDal = maintenanceandRepairDal;
        }

        public void TAdd(MaintenanceandRepair entity)
        {
            _maintenanceandRepairDal.Add(entity);
        }

        public void TDelete(MaintenanceandRepair entity)
        {
            _maintenanceandRepairDal.Delete(entity);
        }

        public List<MaintenanceandRepair> TGetAll()
        {
            return _maintenanceandRepairDal.GetAll();
        }

        public MaintenanceandRepair TGetByID(int id)
        {
            return _maintenanceandRepairDal.GetByID(id);
        }

        public void TUpdate(MaintenanceandRepair entity)
        {
            _maintenanceandRepairDal.Update(entity);
        }
    }
}
