﻿using Butce.BusinessLayer.Abstract;
using Butce.DataAccessLayer.Abstract;
using Butce.EntityLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.BusinessLayer.Concrete
{
    public class MainCodeManager : IMainCodeService
    {
        private readonly IMainCodeDal _maincodeDal;

        public MainCodeManager(IMainCodeDal maincodeDal)
        {
            _maincodeDal = maincodeDal;
        }

        public void TAdd(MainCode entity)
        {
            _maincodeDal.Add(entity);
        }

        public void TDelete(MainCode entity)
        {
            _maincodeDal.Delete(entity);
        }

        public List<MainCode> TGetAll()
        {
            return _maincodeDal.GetAll();
        }

        public MainCode TGetByID(int id)
        {

            return _maincodeDal.GetByID(id);
        }

        public void TUpdate(MainCode entity)
        {
            _maincodeDal.Update(entity);
        }
    }
}
