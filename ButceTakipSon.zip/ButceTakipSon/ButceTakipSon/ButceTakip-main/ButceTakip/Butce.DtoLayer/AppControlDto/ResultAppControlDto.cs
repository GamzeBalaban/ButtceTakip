﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.DtoLayer.AppControlDto
{
    public class ResultAppControlDto
    {

        public bool AppControls { get; set; }

      
    }
}
