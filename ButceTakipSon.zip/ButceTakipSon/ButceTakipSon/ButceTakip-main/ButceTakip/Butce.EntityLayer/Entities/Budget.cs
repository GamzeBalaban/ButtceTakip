﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.EntityLayer.Entities
{
    public class Budget
    {
        public int BudgetTypeID { get; set; }

        public string BudgetType { get; set; }

    }
}
