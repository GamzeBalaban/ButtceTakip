﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.DtoLayer.ProxyDto
{
    public class ResultProxyDto
    {
        public int ProxyID { get; set; }

        public string Name { get; set; }

        public string PersonelTask { get; set; }
        public string PersonelState { get; set; }
    }
}
