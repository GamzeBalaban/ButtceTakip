﻿using Butce.BusinessLayer.Abstract;
using Butce.DataAccessLayer.Abstract;
using Butce.DataAccessLayer.EntityFramework;
using Butce.EntityLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.BusinessLayer.Concrete
{
    public class InvestmentManager : IInvestmentService
    {
        private readonly IInvestmentDal _investmentDal;

        public InvestmentManager(IInvestmentDal investmentDal)
        {
            _investmentDal = investmentDal;
        }

        public void TAdd(Investment entity)
        {
            _investmentDal.Add(entity);
        }

        public void TDelete(Investment entity)
        {
            _investmentDal.Delete(entity);
        }

        public List<Investment> TGetAll()
        {
            return _investmentDal.GetAll();
        }

        public Investment TGetByID(int id)
        {
            return _investmentDal.GetByID(id);
        }

        public void TUpdate(Investment entity)
        {
            _investmentDal.Update(entity);
        }
    }
}
