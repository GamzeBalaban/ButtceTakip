﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Butce.EntityLayer.Entities
{
    public class AppControl
    {
        public int ID { get; set; }

        public bool AppControls { get; set; }

        public MainCode MainCode { get; set; }

    }
}
